/* Signal delivery: sync + async handlers, SIGCHLD, sigsuspend, EINTR. */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

static volatile sig_atomic_t usr1, spin_hit, chld;
static void on_usr1(int s) { usr1++; }
static void on_int(int s) { spin_hit = 1; }
static void on_chld(int s, siginfo_t *si, void *uc) { chld++; }

int main(void) {
    signal(SIGUSR1, on_usr1);
    kill(getpid(), SIGUSR1);
    kill(getpid(), SIGUSR1);
    printf("1. self SIGUSR1 x2 -> handler ran %d times\n", usr1);

    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_chld;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGCHLD, &sa, 0);
    signal(SIGINT, on_int);
    pid_t parent = getpid();
    pid_t c = fork();
    if (c == 0) {                       /* child: poke the busy parent, then exit */
        usleep(100000);
        kill(parent, SIGINT);
        _exit(7);
    }
    double x = 1.0;
    while (!spin_hit) x = x * 1.0000001;  /* pure ring-3 loop: async delivery */
    printf("2. SIGINT interrupted a busy loop (fpu intact: %s)\n", x > 1.0 ? "yes" : "no");
    int st;
    waitpid(c, &st, 0);
    printf("3. child exit=%d, SIGCHLD handler ran %d time(s)\n", WEXITSTATUS(st), chld);

    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGUSR1);
    sigprocmask(SIG_BLOCK, &block, &old);
    if (fork() == 0) { usleep(50000); kill(getppid(), SIGUSR1); _exit(0); }
    usr1 = 0;
    sigsuspend(&old);                   /* atomically unblock + wait */
    printf("4. sigsuspend woke by SIGUSR1: %s\n", usr1 ? "yes" : "no");
    wait(0);

    int fds[2];
    pipe(fds);
    signal(SIGUSR1, on_usr1);           /* no SA_RESTART with signal()? musl uses it */
    sa.sa_handler = on_usr1; sa.sa_flags = 0;
    sigaction(SIGUSR1, &sa, 0);
    sigprocmask(SIG_SETMASK, &old, 0);
    if (fork() == 0) { usleep(50000); kill(getppid(), SIGUSR1); _exit(0); }
    char b;
    int r = read(fds[0], &b, 1);
    printf("5. blocking read interrupted: r=%d errno=%s\n", r, r < 0 && errno == EINTR ? "EINTR" : "?");
    wait(0);
    return 0;
}
