/* TCP echo over loopback + an HTTP GET: sockets from C.
   usage: net                 (self-test on 127.0.0.1)
          net <host> [path] [port]   (HTTP GET, e.g. net example.org /) */
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

static int selftest(void) {
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_port = htons(7777) };
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) || listen(ls, 4)) { perror("listen"); return 1; }
    if (fork() == 0) {                       /* client */
        int c = socket(AF_INET, SOCK_STREAM, 0);
        if (connect(c, (struct sockaddr *)&a, sizeof a)) { perror("connect"); _exit(1); }
        const char *msg = "ping over TCP loopback";
        write(c, msg, strlen(msg));
        char buf[64] = {0};
        int n = read(c, buf, sizeof buf - 1);
        printf("client got %d bytes: %s\n", n, buf);
        close(c);
        _exit(0);
    }
    struct sockaddr_in peer; socklen_t pl = sizeof peer;
    int s = accept(ls, (struct sockaddr *)&peer, &pl);
    char buf[64] = {0};
    int n = read(s, buf, sizeof buf - 1);
    printf("server accepted %s:%d, got \"%s\"\n", inet_ntoa(peer.sin_addr), ntohs(peer.sin_port), buf);
    for (int i = 0; i < n; i++) if (buf[i] >= 'a' && buf[i] <= 'z') buf[i] -= 32;
    write(s, buf, n);
    close(s);
    wait(0);
    close(ls);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) return selftest();
    struct addrinfo hints = { .ai_family = AF_INET, .ai_socktype = SOCK_STREAM }, *ai;
    int e = getaddrinfo(argv[1], argc > 3 ? argv[3] : "80", &hints, &ai);
    if (e) { fprintf(stderr, "resolve %s: %s\n", argv[1], gai_strerror(e)); return 1; }
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(s, ai->ai_addr, ai->ai_addrlen)) { perror("connect"); return 1; }
    char req[256];
    int len = snprintf(req, sizeof req, "GET %s HTTP/1.0\r\nHost: %s\r\n\r\n", argc > 2 ? argv[2] : "/", argv[1]);
    write(s, req, len);
    char buf[1024];
    int n;
    while ((n = read(s, buf, sizeof buf)) > 0) fwrite(buf, 1, n, stdout);
    close(s);
    return 0;
}
