/* Exercises malloc, qsort, stdio files, 64-bit math and floating point. */
#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *a, const void *b) { return *(const int *)a - *(const int *)b; }

int main(void) {
    int n = 20000, *v = malloc(n * sizeof *v);
    unsigned long long h = 1469598103934665603ULL;
    for (int i = 0; i < n; i++) {
        v[i] = (i * 7919) % 10007;
        h = (h ^ (unsigned)v[i]) * 1099511628211ULL;
    }
    qsort(v, n, sizeof *v, cmp);
    FILE *f = fopen("demo.out", "w");
    fprintf(f, "min=%d max=%d hash=%llu div=%llu\n", v[0], v[n - 1], h, h / 12345);
    fclose(f);
    char buf[128];
    f = fopen("demo.out", "r");
    fgets(buf, sizeof buf, f);
    fclose(f);
    printf("%s", buf);
    printf("pi ~ %.6f\n", 355.0 / 113.0);
    free(v);
    return 0;
}
