#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv) {
    printf("Hello from TCC on SamaraOS! pid=%d\n", getpid());
    for (int i = 1; i < argc; i++) printf("  arg %d: %s\n", i, argv[i]);
    return 0;
}
