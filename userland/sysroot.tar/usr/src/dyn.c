#include <stdio.h>
#include <dlfcn.h>
int dyn_add(int a, int b);
int main(void) {
    printf("dynamic hello, 2+3=%d\n", dyn_add(2, 3));
    void *h = dlopen("libdyn.so", RTLD_NOW);
    int (*f)(int, int) = h ? (int (*)(int, int))dlsym(h, "dyn_add") : 0;
    printf("dlopen: %s, f(40,2)=%d\n", h ? "ok" : dlerror(), f ? f(40, 2) : -1);
    return 0;
}
