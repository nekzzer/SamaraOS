# HTTP GET over the SamaraOS TCP stack.
# usage: micropython http.py [host] [path] [port]   (default: host:8080 /, see serve.py)
import sys, socket
host = sys.argv[1] if len(sys.argv) > 1 else "host"
path = sys.argv[2] if len(sys.argv) > 2 else "/"
port = int(sys.argv[3]) if len(sys.argv) > 3 else 8080
addr = socket.getaddrinfo(host, port)[0][-1]
s = socket.socket()
s.connect(addr)
s.send(b"GET %s HTTP/1.0\r\nHost: %s\r\n\r\n" % (path.encode(), host.encode()))
while True:
    chunk = s.recv(1024)
    if not chunk:
        break
    sys.stdout.buffer.write(chunk)
s.close()
