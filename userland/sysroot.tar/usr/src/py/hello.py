import sys, os, time
print("Hello from MicroPython on SamaraOS!")
print("version:", sys.version)
print("pid:", os.getpid(), " cwd:", os.getcwd())
print("args:", sys.argv[1:])
print("files in /usr/src:", os.listdir("/usr/src"))
t = time.ticks_ms()
print("primes < 2000:", len([n for n in range(2, 2000) if all(n % d for d in range(2, int(n ** 0.5) + 1))]))
print("took", time.ticks_diff(time.ticks_ms(), t), "ms;  2**100 =", 2 ** 100)
