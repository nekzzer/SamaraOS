# File I/O + json round-trip in the ramfs (use /mnt/... to persist on disk).
import json
data = {"os": "SamaraOS", "lang": "MicroPython", "nums": [1, 2, 3], "pi": 3.14159}
with open("/tmp/data.json", "w") as f:
    json.dump(data, f)
with open("/tmp/data.json") as f:
    back = json.load(f)
print("wrote and read back:", back)
print("equal:", back == data)
