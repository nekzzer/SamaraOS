#include <bits/kd.h>
